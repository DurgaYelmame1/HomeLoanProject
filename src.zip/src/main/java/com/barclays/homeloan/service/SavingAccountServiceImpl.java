package com.barclays.homeloan.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.barclays.homeloan.dto.SavingAccount;
import com.barclays.homeloan.repo.SavingAccountRepository;

@Service
public class SavingAccountServiceImpl implements SavingAccountService {

	@Autowired
	SavingAccountRepository repository;

	@Override
	public SavingAccount createAccount(SavingAccount savingAccount) {
		// TODO Auto-generated method stub
		return repository.save(savingAccount);
	}

	@Override
	public Optional<SavingAccount> getSavingAccountDetail(int squenceId) {
		// TODO Auto-generated method stub
		return repository.findById(squenceId);
	}
	
	
}
