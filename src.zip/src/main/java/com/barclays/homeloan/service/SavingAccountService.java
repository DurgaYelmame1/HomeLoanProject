package com.barclays.homeloan.service;

import java.util.Optional;

import com.barclays.homeloan.dto.SavingAccount;

public interface SavingAccountService {

	public SavingAccount createAccount(SavingAccount savingAccount);
	
	public Optional<SavingAccount> getSavingAccountDetail(int sequenceId);
}
