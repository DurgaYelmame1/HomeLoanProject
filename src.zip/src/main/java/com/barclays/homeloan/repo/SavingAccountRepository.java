package com.barclays.homeloan.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.barclays.homeloan.dto.SavingAccount;

public interface SavingAccountRepository extends JpaRepository<SavingAccount, Integer>{

}
