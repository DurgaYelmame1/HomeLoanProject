package com.barclays.homeloan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeLoanApplicationTests {

	@Test
	void contextLoads() {
	}

}
